// radio_server.mjs — Minimal Express backend for PlainTalk Radio Booth (Go-Live)
// Run:
//   npm install
//   cp .env.example .env  # then edit OPENAI_API_KEY=
//   node radio_server.mjs
//
// Browse: http://localhost:3000

import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import OpenAI from 'openai';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static('public'));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM_PROMPT = `
SYSTEM STYLE = PlainTalk.
Roles:
• Host: one-line restate + 3 short choices.
• Color: context (why it works, tradeoffs, local time math).
• Producer: runs DO NOW (calls/forms) and returns a *receipt*.
• Screener: tiny risk note only if truly needed (no clinical labels).
Rules:
• Grade-6 words. No "notice/letterhead" voice. No mental-state labels.
• Accept AAVE/heat without tone-policing.
• Return JSON ONLY. No extra text.
`;

// JSON Schema for Structured Outputs (OpenAI Responses API)
// See: https://openai.com/index/introducing-structured-outputs-in-the-api/
const schema = {
  name: "RadioBooth",
  schema: {
    type: "object",
    additionalProperties: false,
    properties: {
      host: { type: "string" },
      choices: {
        type: "array",
        items: { type: "string" },
        minItems: 1,
        maxItems: 3
      },
      next: { type: "string" },
      receipt: { type: "string" },
      color: { type: "string" },
      producer: { type: "string" },
      screener: { type: "string" }
    },
    required: ["host","choices","next","receipt","color","producer","screener"]
  }
};

app.post('/api/radio', async (req, res) => {
  try {
    const { ask, details, state, skin, domain } = req.body || {};
    const userBlock = [
      `ASK: ${ask||''}`,
      details ? `DETAILS: ${details}` : '',
      state ? `STATE: ${JSON.stringify(state)}` : '',
      skin ? `SKIN: ${skin}` : '',
      domain ? `DOMAIN: ${domain}` : ''
    ].filter(Boolean).join("\n");

    const resp = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      instructions: SYSTEM_PROMPT,
      input: userBlock,
      response_format: { type: "json_schema", json_schema: schema }
    });

    // Prefer parsed output when available; fall back to text
    let data = null;
    try {
      // Some SDK versions expose output_parsed
      data = resp.output_parsed ?? null;
    } catch {}
    if (!data) {
      const text = resp.output_text ?? (resp.output?.[0]?.content?.[0]?.text ?? "");
      data = JSON.parse(text);
    }

    res.json({ ok: true, data, request_id: resp._request_id });
  } catch (err) {
    console.error("API error:", err);
    res.status(500).json({ ok:false, error: String(err) });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`PlainTalk Radio server listening on http://localhost:${PORT}`);
});