PlainTalk Radio • Go-Live
=========================

What this is
------------
A tiny Express server + HTML page that posts your input to `/api/radio`,
which calls the **OpenAI Responses API** with **Structured Outputs** to
get a strict JSON back (host/choices/next/receipt/color/producer/screener).

How to run (local)
------------------
1) Ensure Node 20+ installed.
2) Unzip this folder. In the folder, run:
     npm install
3) Copy the env template and set your key:
     cp .env.example .env
     # then edit .env and set OPENAI_API_KEY=sk-...
4) Start the server:
     npm start
5) Open your browser to:
     http://localhost:3000

Change the model
----------------
Default is `gpt-4o-mini`. You can set `OPENAI_MODEL=gpt-4o` or another
supported model.

Security notes
--------------
- This server is a quickstart. Put it behind your own auth before exposing it.
- Logs include only request IDs (no user data).
- Do not paste secrets into the UI.

Docs (official)
---------------
- openai-node usage & Responses API example (response.output_text): https://github.com/openai/openai-node
- Structured Outputs announcement: https://openai.com/index/introducing-structured-outputs-in-the-api/

© ALMG 2025